package com.example.slider_images;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    int i = 2;

    public void nextImages(View view){
        Log.i("layout", "This is Main Layout");

        Log.i("click", "click button to next image");

        ImageView img = (ImageView) findViewById(R.id.imageViewCat);

        if(i%2 == 0){
            img.setImageResource(R.drawable.cat2);
            this.i++;
        }else{
            img.setImageResource(R.drawable.cat1);
            this.i++;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
