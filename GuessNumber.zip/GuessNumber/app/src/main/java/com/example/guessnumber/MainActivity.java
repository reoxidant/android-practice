package com.example.guessnumber;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;


public class MainActivity extends AppCompatActivity {
    private int min = 1;
    private int max = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void successButtonClick(View view){
        EditText input_number = findViewById(R.id.input_number);

        String text_number = input_number.getText().toString();

        if(TextUtils.isEmpty(text_number)){
            input_number.setError("Empty value!");
            return;
        }

        if(Integer.parseInt(text_number) > 1000 || Integer.parseInt(text_number) < 1) {
            Toast.makeText(this, "Out of range numbers, use a numbers between 1 and 1000.", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, text_number, Toast.LENGTH_SHORT).show();
        }
    }
}