package com.example.guessnumber;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;


public class MainActivity extends AppCompatActivity {
    private int min = 1;
    private int max = 20;
    private int guess_number = new Random().nextInt(max - min + 1)+min;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void successButtonClick(View view){
        EditText input_number = findViewById(R.id.input_number);

        int length_number = input_number.getText().toString().trim().length();

        int number = Integer.parseInt(input_number.getText().toString());

        if(length_number == 0){
            Toast.makeText(this, "Empty number", Toast.LENGTH_SHORT).show();
        }else if(number < min || number > max){
            Toast.makeText(this, "Out of range", Toast.LENGTH_SHORT).show();
        }else if(number == guess_number){
            Toast.makeText(this, "Congratulations you guess my number!", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Not my number!", Toast.LENGTH_SHORT).show();
        }
    }
}