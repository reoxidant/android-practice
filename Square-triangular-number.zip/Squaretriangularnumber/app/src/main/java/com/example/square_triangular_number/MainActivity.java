package com.example.square_triangular_number;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    class triangularAndSquareNumber{

        public void findTriangularAndSquareValues(String text_number){
            int number = Integer.parseInt(text_number);
            if(!validateNumber(number) && !text_number.isEmpty()){
                findNumber(number);
            }
        }

        private boolean findSquareNumber(int number){
            double squareNumber = Math.sqrt(number);
            return Math.floor(squareNumber) == squareNumber;
        }

        private boolean findTriangularNumber(int number){
            int triangularNumber = 0;
            for(int i = 1; i <= number; i++){
                triangularNumber = i + triangularNumber;
                if(triangularNumber == number){
                    break;
                }
            }
            return triangularNumber == number;
        }

        private boolean validateNumber(int num){
            if(num > 1000000){
                Toast.makeText(MainActivity.this, "Value more that 1 million it is out of range!", Toast.LENGTH_LONG).show();
                return true;
            }else if(num < 0){
                Toast.makeText(MainActivity.this, "Value number is less that 0, enter a correct number!", Toast.LENGTH_LONG).show();
                return true;
            }else{
                return false;
            }
        }

        private void findNumber(int number){
            if(findSquareNumber(number) && findTriangularNumber(number)){
                Toast.makeText(MainActivity.this, "This number is square and triangular number!", Toast.LENGTH_LONG).show();
            }else if(findSquareNumber(number) && !findTriangularNumber(number)){
                Toast.makeText(MainActivity.this, "This number is square number!", Toast.LENGTH_LONG).show();
            }else if(findTriangularNumber(number) && !findSquareNumber(number)){
                Toast.makeText(MainActivity.this, "This number is triangular number!", Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(MainActivity.this, "This number is not square and triangular number!", Toast.LENGTH_LONG).show();
            }
        }
    }

    public void onButtonClick(View view){
        TextView input_number = findViewById(R.id.input);
        Log.i("button clicked", input_number.getText().toString());

        triangularAndSquareNumber number = new triangularAndSquareNumber();

        number.findTriangularAndSquareValues(input_number.getText().toString());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}