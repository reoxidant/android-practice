package com.example.reacting_the_goals;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.os.SystemClock;
import java.util.Date;


public class MainActivity extends AppCompatActivity {

    private long startTime = 0;
    private long calculateInputVal = 0;
    public static final String APP_PREFERENCES = "appsettings";
    public static final String APP_PREFERENCES_COUNTER = "counter_time";
    public static final String APP_PREFERENCES_CALCULATE = "calculate_calories";
    private SharedPreferences appSetting;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        appSetting = getSharedPreferences(APP_PREFERENCES, Context.MODE_PRIVATE);
        Calories calories = new Calories();
        if(startTime == 0){
            startTime = new Date().getTime();
            calories.start(startTime, true);
        }
    }

    class Calories{
        TextView viewCalories;
        Button start, calculateCalories;
        EditText calculateInput;
        Handler handler;
        long saveSeconds, oldTime, curTime, saveTime;
        int  secondsInOneCalories;

        public void start(long saveTimeTimestamp, boolean btnEnable){
            viewCalories = findViewById(R.id.viewCalories);
            start = findViewById(R.id.buttonStart);
            calculateCalories = findViewById(R.id.buttonCalories);
            calculateInput = findViewById(R.id.textCalories);

            handler = new Handler() ;
            saveTime = saveTimeTimestamp;

            if(!btnEnable){
                handler.postDelayed(runnable, 0);
                start.setEnabled(false);
            }


            start.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    handler.postDelayed(runnable, 0);
                    start.setEnabled(false);
                }
            });

            calculateCalories.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    if(calculateInput.getText().toString().length() != 0){
                        MainActivity.this.calculateInputVal += Long.parseLong(calculateInput.getText().toString());
                    }
                }
            });

        }
        public Runnable runnable = new Runnable() {
            public void run() {
                secondsInOneCalories = (24 * 60 * 60) / 2100;
                //1 week 39 seconds in 1 cal
                //2 week 41 seconds in 1 cal
                oldTime = new Date(saveTime).getTime();
                curTime = new Date().getTime();

                saveSeconds = (curTime - oldTime)/1000;
                viewCalories.setText(String.valueOf((saveSeconds / secondsInOneCalories) - MainActivity.this.calculateInputVal));

                handler.postDelayed(this, 0);
            }
        };
    }


    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences.Editor editor = appSetting.edit();
        editor.putLong(APP_PREFERENCES_COUNTER, startTime);
        editor.putLong(APP_PREFERENCES_CALCULATE, calculateInputVal);
        editor.apply();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (appSetting.contains(APP_PREFERENCES_COUNTER) && appSetting.contains(APP_PREFERENCES_CALCULATE)) {
            startTime = appSetting.getLong(APP_PREFERENCES_COUNTER, 0);
            calculateInputVal = appSetting.getLong(APP_PREFERENCES_CALCULATE, 0);
            Calories calories = new Calories();
            calories.start(startTime, false);
        }
    }
}