package com.example.input_data;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    public void clickFunction(View view){
        EditText inputTextLogin = (EditText) findViewById(R.id.inputTextLogin);
        EditText inputTextPassword = (EditText) findViewById(R.id.inputTextPassword);

        Log.i("Login", inputTextLogin.getText().toString());
        Log.i("Password", inputTextPassword.getText().toString());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
